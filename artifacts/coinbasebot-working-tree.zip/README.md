# Coinbase Agentic Wallet (coinbasebot)

This repo wires a Coinbase **Agentic Wallet** into Cursor and Claude Code so an agent can hold USDC, swap on Base, and pay for [x402](https://docs.cdp.coinbase.com/x402/welcome) APIs.

No Coinbase API keys or seed phrases. You sign in with email, set spending limits, and the agent operates inside those limits.

## Coinbase.com vs this wallet

They are **not the same account**.

| | Coinbase.com app / exchange | Agentic Wallet (this project) |
| --- | --- | --- |
| Where it lives | Your Coinbase login | Embedded wallet tied to an email (here: `kraftcoding@gmail.com`) |
| How you see it | Coinbase app | `npx awal show` or “Show me my wallet” |
| Trading | Coinbase Advanced Trade | `npx awal trade` on **Base** only |
| Balance you funded | Stays $0 unless you withdraw there | USDC sent to the Base receive address |

**Base (EVM) receive address:** `0xD10d7eA8B847110f3bbf71781ABefbac01517b82`

**Solana receive address:** `HCCQTfNtw7dUCB84VCtpEbkAuztLH3B1eUC5Kd9v3Raf`

If Coinbase.com shows $0, check this wallet instead (`npm run wallet:balance`).

## What each client can do

| Client | How it connects | Pay for APIs (x402) | Swap / trade tokens |
| --- | --- | --- | --- |
| Claude Desktop | Payments MCP only | Yes | No |
| Claude Code / Cursor | MCP **plus** [`.claude/skills/agentic-wallet`](.claude/skills/agentic-wallet) | Yes | Yes (`npx awal trade`) |

Trading is **Base mainnet only**. Example: `npx awal trade 1 usdc eth`.

Do **not** turn on an unattended looping strategy. First live action is a **$1 USDC → ETH** smoke test.

## Prerequisites

- Node.js 22 or newer (`node -v`)
- npm
- Claude Code (for swaps) and/or Cursor
- Claude Desktop only if you want x402 payments in the Desktop app

## Install on Windows (Claude Code)

Run these on the PC where Claude Code is installed. Use **Windows PowerShell** for the MCP installer (Claude Desktop/Code are Windows apps). Origin CLI clone can stay in WSL.

```powershell
# From this repo
npx @coinbase/payments-mcp --client claude-code --auto-config
npx skills add coinbase/agentic-wallet-skills --agent claude-code -y

npx awal auth login kraftcoding@gmail.com
npx awal auth verify <6-digit-code>
npx awal show
```

In the wallet UI, set spending limits **before** Claude trades:

- **Max per call:** `$1`
- **Max per session:** `$5`

Claude cannot raise these. Restart Claude Code after install.

### Smoke-test prompts

```
What's my wallet balance?
```

```
Swap $1 USDC for ETH on Base
```

If the swap is over your per-call cap, it is blocked. If the balance is 0, you funded Coinbase.com or the wrong chain.

## Claude Desktop (x402 only, no swaps)

In **Windows PowerShell** (not this Linux cloud VM, not WSL):

```powershell
npx @coinbase/payments-mcp --client claude --auto-config
```

If auto-config does not write the file, edit `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "payments-mcp": {
      "command": "node",
      "args": ["%USERPROFILE%\\.payments-mcp\\bundle.js"]
    }
  }
}
```

If `%USERPROFILE%` does not expand in your Claude build, use the absolute path, for example `C:\\Users\\YOUR_WINDOWS_USERNAME\\.payments-mcp\\bundle.js`.

Do not paste Linux paths (`/home/ubuntu/...`) into Claude on Windows. Fully quit and reopen Claude Desktop, then ask: **Show me my wallet**.

## Cursor (this repo)

[`.cursor/mcp.json`](.cursor/mcp.json) starts Payments MCP via [`scripts/run-payments-mcp.mjs`](scripts/run-payments-mcp.mjs). MCP still cannot swap; Cursor uses the skill + `awal` for trades.

```bash
npm run mcp:install
npm run wallet:status
npm run wallet:balance
npm run wallet:show
```

## First-time funding

1. `npm run wallet:show` (or “Show me my wallet”).
2. Sign in with email OTP (`kraftcoding@gmail.com` for the funded wallet).
3. **Fund** (Coinbase Onramp) or **Receive** and send **USDC on Base** to the EVM address above.
4. Set max per call `$1` and max per session `$5`.

## npm scripts

```bash
npm run mcp:install      # install Payments MCP into ~/.payments-mcp
npm run mcp:status
npm run skills:install   # refresh .claude/skills/agentic-wallet
npm run wallet:status
npm run wallet:balance
npm run wallet:show
```

## Commands

```bash
npx @coinbase/payments-mcp
npx @coinbase/payments-mcp --client claude-code --auto-config
npx awal status
npx awal balance
npx awal trade 1 usdc eth
npx awal x402 bazaar search "crypto news"
```

## Troubleshooting

- **Coinbase app shows $0** — Funds are in the Agentic Wallet on Base, not the exchange.
- **Claude Desktop cannot swap** — Install Claude Code and the agentic-wallet skill.
- **MCP tools missing** — Confirm `~/.payments-mcp/bundle.js` (or `%USERPROFILE%\.payments-mcp\bundle.js`) exists, then restart the client.
- **Wallet UI never opens** — The companion app is Electron; you need a desktop session. Run `npm run wallet:show`.
- **OTP expired** — `npx awal auth login kraftcoding@gmail.com` and use the newest email code.
- **Git push 403 to Origin** — This cloud agent token cannot create or write Origin repos (`repository_access_denied`). Workarounds:
  1. Download `coinbasebot.bundle` or `coinbasebot-working-tree.zip` from the agent artifacts, then on your PC: `bash scripts/import-bundle.sh coinbasebot.bundle` and `bash scripts/push-from-your-pc.sh` after `origin auth login`.
  2. Or create a GitHub repo from your PC: `npm run publish:github` (needs `gh auth login`).
  3. Cursor on Windows: copy [config/cursor.mcp.windows.json](config/cursor.mcp.windows.json) over `%USERPROFILE%\.cursor\mcp.json` (uses `C:\Users\phsok\.payments-mcp\bundle.js`).

Official docs: [Agentic Wallet CLI](https://docs.cdp.coinbase.com/agentic-wallet/cli/quickstart), [MCP quickstart](https://docs.cdp.coinbase.com/agentic-wallet/mcp/quickstart), [trade skill](https://docs.cdp.coinbase.com/agentic-wallet/cli/skills/trade).

## Repositories

**Origin:** [ivorycrowncollective/coinbasebot](https://cursor.com/codebase/ivorycrowncollective/coinbasebot) — private. Clone in WSL:

```bash
curl -fsSL https://downloads.cursor.com/origin/install.sh | sh
origin auth login
origin repo clone ivorycrowncollective/coinbasebot
```

If `origin` is not found:

```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

**GitHub:** after `gh auth login`:

```bash
npm run publish:github
bash scripts/publish-to-github.sh ivorycrowncollective/coinbasebot private
```
